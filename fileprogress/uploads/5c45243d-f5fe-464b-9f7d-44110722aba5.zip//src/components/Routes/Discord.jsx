import React, {useEffect} from 'react';

function Discord() {
  useEffect(() => {
    window.location.href = 'https://discord.gg/8XJSzmtWPp';
  }, []);
  return <div></div>;
}

export default Discord;
