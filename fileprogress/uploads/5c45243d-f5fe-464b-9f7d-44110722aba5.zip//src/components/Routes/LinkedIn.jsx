import React, {useEffect} from 'react';

function Linkedin() {
  useEffect(() => {
    window.location.href = 'https://www.linkedin.com/company/limbo-hacks/';
  }, []);
  return <div></div>;
}

export default Linkedin;
