import React, {useEffect} from 'react';

function Devpost() {
  useEffect(() => {
    window.location.href = 'https://limbo-hacks-12968.devpost.com/';
  });
  return <div></div>;
}

export default Devpost;
