[
  {
    day: '8-11-2021',
    events: [
      {
        title: 'Intro to phycycology',
        timings: '12 AM - 1 Pm',
        content:
          'JAVA was developed by Sun Microsystems Inc in 1991, later acquired by Oracle Corporation. It was developed by James Gosling and Patrick Naughton. It is a simple programming language.  Writing, compiling and debugging a program is easy in java.  It helps to create modular programs and reusable code.',
        image: 'https://i.imgur.com/EjM8qVK.jpg',
        organizer: 'Porf Juliana',
        role: 'Software Engineer',
        company: 'JP Morgan'
      }
    ]
  },
  {
    day: '5-12-2021',
    events: [
      {
        title: 'Intro to deep learning',
        timings: '12 AM - 1 Pm',
        content:
          'JAVA was developed by Sun Microsystems Inc in 1991, later acquired by Oracle Corporation. It was developed by James Gosling and Patrick Naughton. It is a simple programming language.  Writing, compiling and debugging a program is easy in java.  It helps to create modular programs and reusable code.',
        image: 'https://i.imgur.com/EjM8qVK.jpg',
        organizer: 'Rahul Dravid',
        role: 'Software Engineer',
        company: 'JP Morgan'
      },
      {
        title: 'Intro to deep learning',
        timings: '12 AM - 1 Pm',
        content:
          'JAVA was developed by Sun Microsystems Inc in 1991, later acquired by Oracle Corporation. It was developed by James Gosling and Patrick Naughton. It is a simple programming language.  Writing, compiling and debugging a program is easy in java.  It helps to create modular programs and reusable code.',
        image: 'https://i.imgur.com/EjM8qVK.jpg',
        organizer: 'Rahul Dravid',
        role: 'Software Engineer',
        company: 'JP Morgan'
      }
    ]
  },
  {
    day: '3-12-2021',
    events: [
      {
        title: 'Intro to phycycology',
        timings: '12 AM - 1 Pm',
        content:
          'JAVA was developed by Sun Microsystems Inc in 1991, later acquired by Oracle Corporation. It was developed by James Gosling and Patrick Naughton. It is a simple programming language.  Writing, compiling and debugging a program is easy in java.  It helps to create modular programs and reusable code.',
        image: 'https://i.imgur.com/EjM8qVK.jpg',
        organizer: 'Porf Juliana',
        role: 'Software Engineer',
        company: 'JP Morgan'
      }
    ]
  },
  {
    day: '1-12-2021',
    events: [
      {
        title: 'Intro to deep learning',
        timings: '12 AM - 1 Pm',
        content:
          'JAVA was developed by Sun Microsystems Inc in 1991, later acquired by Oracle Corporation. It was developed by James Gosling and Patrick Naughton. It is a simple programming language.  Writing, compiling and debugging a program is easy in java.  It helps to create modular programs and reusable code.',
        image: 'https://i.imgur.com/EjM8qVK.jpg',
        organizer: 'Rahul Dravid',
        role: 'Software Engineer',
        company: 'JP Morgan'
      }
    ]
  }
];
